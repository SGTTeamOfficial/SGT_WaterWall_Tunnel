<p align="center">
<picture>
<img width="160" height="160"  alt="XPanel" src="https://github.com/ahmteam/waterwall/blob/main/src/logo.jpg">
</picture>
  </p> 
<p align="center">
<h1 align="center"/>WaterWall Tunnel</h1>
<h6 align="center"> تانل واتر وال <h6>
</p>

## پیش نیاز

اوبنتو 20 و بالاتر

------------------------
 <div align="right">
  <details>
    <summary><strong><img src="https://github.com/Azumi67/FRP_Reverse_Loadbalance/assets/119934376/ae5b07b8-4d5e-4302-a31f-dec2a79a76b5" alt="Image"> ویدیوهای آموزشی</strong></summary>
------------------------------------   
  
- **ویدیوی آموزشی توسط 69**
<div align="right">
  <a href="https://youtu.be/sn0-ABfIcx4">
    <img src="https://github.com/69learn/waterwall/blob/main/src/t.png" alt="Video Title" width="300">
  </a>
</div>
  </details>
</div>

---------------------------------
## نصب

- اسکریپت روی هر دو سرور اجرا شود (خارج و ایران )



### mux (http2 , mux , grpc)


```
bash <(curl https://raw.githubusercontent.com/ahmteam/waterwall/main/mux.sh)


```
------------------------------------ 
 <div align="right">
  <details>
    <summary><strong><img src="https://github.com/Azumi67/FRP_Reverse_Loadbalance/assets/119934376/ae5b07b8-4d5e-4302-a31f-dec2a79a76b5" alt="Image"> ویدیوهای آموزشی</strong></summary>
    ------------------------------------ 

- **ویدیوی آموزشی توسط 69**
<div align="right">
  <a href="https://youtu.be/iXs3Vo5vu2w?si=xstpADmEl6vakJ3M">
    <img src="https://github.com/69learn/waterwall/blob/main/src/t.png" alt="Video Title" width="300">
  </a>
</div>
  </details>
</div>

### Bgp4 (multiport)

```
bash <(curl https://raw.githubusercontent.com/69learn/waterwall/main/Bgp4.sh)

```


### direct reaality(multiport)

```
bash <(curl https://raw.githubusercontent.com/69learn/waterwall/main/direct.sh)

```
---

[لینک اصلی پروژه](https://github.com/radkesvat/WaterWall)
---













# تلگرام

[@sixtininelearn](https://t.me/sixtininelearn)

[@sixti9learn](https://t.me/sixti9learn)





  </p> 




